/* PERMITTED COMMANDS
   move, turnLeft, turnRight, treeLeft, treeRight, treeFront, onLeaf, putLeaf, removeLeaf, mushroomFront
   JAVA
   if, while, for
*/
   
class MyClara extends Clara { 
    /**
     * In the 'run()' method you can write your program for Clara 
     */
    void run() {
        // TODO: Write your code below
    // Foundation of Movement, the use of multiple voids to get around the tree and ultimately get towards the final goal
while (!mushroomFront()){
            if (!treeFront())
            move();
            grabLeaf();
            moveAndTurnRight();
            aroundTree();
            grabLeaf();
        } 
    }
    void moveAndTurnRight(){
        if (treeFront()){
            turnLeft();
            move();
            turnRight();
            move();
        }
        
    }
    void grabLeaf(){
        if (onLeaf()){
            removeLeaf();
        }
    }
    void aroundTree(){
        while (treeRight()){
            move();
        if (!treeRight()){
            turnRight();
            move();
            turnLeft();
        }
        }
        
    }
     
    
}
