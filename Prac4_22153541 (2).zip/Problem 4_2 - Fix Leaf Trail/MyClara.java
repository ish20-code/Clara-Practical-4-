/* PERMITTED COMMANDS
   Clara commands:
   move(); turnLeft(); turnRight(); treeLeft(); treeRight(); treeFront(); onLeaf(); putLeaf(); removeLeaf(); mushroomFront();
   JAVA commands:
   if, else, for, while, do, &&, ||, ! */
   
class MyClara extends Clara { 
    /**
     * In the 'run()' method you can write your program for Clara 
     */
    void run() {
        // TODO: Write your code below
        // Facilating movement 
            while (!mushroomFront()){
                putLeaves();
                move();
                
        // Prompting to turn Clara in the Right direction
            if (treeFront()){
            turnLeft();
            }
        // This allows Clara to place a leaf in front of the mushroom
            if (treeLeft() && treeRight() && !onLeaf()){
                putLeaf();
            }
        }
    }
    void putLeaves(){
        if (!onLeaf()){
                putLeaf();
            }
    }
}