/* PERMITTED COMMANDS
   Clara commands:
   move(); turnLeft(); turnRight(); treeLeft(); treeRight(); treeFront(); onLeaf(); putLeaf(); removeLeaf(); mushroomFront();
   JAVA commands:
   if, while, for, do, !, ||, &&
    */
   
class MyClara extends Clara { 
    /**
     * In the 'run()' function you can write your program for Clara 
     */
    void run() {
        // TODO: Write your code below
        // Foundation of Movement and allowed me to get leaves
        while (!mushroomFront()){
            if (onLeaf()){
                removeLeaf();
            }
            move();

        // Included forms of hard code to get around the leaves the right way as normal if and while statements were not gonna work
            if (treeFront() && treeRight()){
                turnLeft();
                if (treeFront()){
                    moveAround();
                }
                if (treeRight() && onLeaf()){
                    grabLeaves();  
                }
                }
        // Turning Clara Right
            if (treeFront()){
                turnRight();
            }   
        }  
    }
    void moveAround(){
                    turnLeft();
                    move();
                    move();
                    turnRight();
                    move();
                    move();
                    removeLeaf();
                    move();
                    removeLeaf();
        }
    void grabLeaves(){
        removeLeaf();
                    move();
                    removeLeaf();
                    turnRight();
                    move();
                    removeLeaf();
                    move();
                    removeLeaf();
                    move();
                    removeLeaf();
                    turnLeft();
                    move();
                    removeLeaf();
                    move();
                    removeLeaf();
                    move();
                    removeLeaf();
    }
    }